# Our Tournament — Android অ্যাপ সোর্স (Firebase যুক্ত প্রাথমিক সংস্করণ)

## টুর্নামেন্টের নির্দিষ্ট তথ্য
- নাম: আব্দুল হামিদ মেম্বার কর্তৃক আয়োজিত সৌদি রিয়াল প্রাইজমানি নাইট মিনিবার ফুটবল টুর্নামেন্ট
- স্থান: জালালাবাদ, ঈদগাঁও, কক্সবাজার
- ভেন্যু: বাহারছড়া সরকারি প্রাথমিক বিদ্যালয়ের মাঠ প্রাঙ্গণ
- ১৬ দল, একক নকআউট; Round of 16 = ৮, Quarter Final = ৪, Semi Final = ২, Final = ১; সর্বমোট ১৫ ম্যাচ
- ম্যাচ শুরু রাত ৮:৩০
- প্রতি দলে ৫ জন মূল খেলোয়াড় ও ২ জন অতিরিক্ত খেলোয়াড়
- ড্র হলে প্রথমে ৩টি করে পেনাল্টি; এরপর ১টি করে পালাক্রমে, বিজয়ী নির্ধারিত না হওয়া পর্যন্ত

## এই প্যাকেজে যা প্রস্তুত আছে
- Firebase Android options অ্যাপের মধ্যে যুক্ত করা হয়েছে (google-services.json আলাদা করে লাগবে না এই Flutter build path-এ)।
- অনুমোদিত টুর্নামেন্ট ক্রেস্ট asset যুক্ত করা হয়েছে।
- ১৬ দলের নাম ও প্রথম রাউন্ডের ৮টি ম্যাচের নির্ধারিত তারিখ/ফল seed করার প্রাথমিক কোড আছে।
- প্রথম ৩ ম্যাচের স্কোর, পেনাল্টি ও বিজয়ী যুক্ত আছে।
- ম্যাচ কার্ডে তারিখ, বার, সময়, ভেন্যু ও স্থান দেখানোর ভিত্তি আছে।
- Firestore এবং Storage-এর জন্য Admin-only write rules দেওয়া আছে।
- GitHub Actions workflow দিয়ে APK build করা যাবে।

## APK build
GitHub repository-তে `Our_Tournament_App_Source.zip` এবং `.github/workflows/build-apk.yml` রাখতে হবে। এরপর GitHub → Actions → Build Our Tournament APK → Run workflow। Build সফল হলে Actions run-এর Artifacts থেকে APK নামাতে হবে।

## Firebase সেটআপ (একবারই করতে হবে)
1. Firebase Console → Authentication → Sign-in method → Email/Password Enable করুন।
2. Authentication → Users-এ `nasarulislam440@gmail.com` অ্যাকাউন্ট তৈরি করুন। পাসওয়ার্ড কাউকে দেবেন না।
3. Firestore Database → Rules-এ `firestore.rules`-এর নিয়ম Publish করুন।
4. Storage → Get started → Rules-এ `storage.rules`-এর নিয়ম Publish করুন।
5. অ্যাপে Admin হিসেবে লগইন করে “১৫টি Knockout ম্যাচ তৈরি/রিসেট” বাটন একবার চাপুন। এটি ১৬টি দলের নথি এবং ১৫টি ম্যাচের প্রাথমিক তথ্য তৈরি করবে।

## গুরুত্বপূর্ণ নিরাপত্তা ও সীমাবদ্ধতা
- Firestore/Storage সবাই পড়তে পারবে; শুধু `nasarulislam440@gmail.com`-এর verified account লিখতে পারবে।
- এই ZIP এখনো পূর্ণ SofaScore-সমমানের চূড়ান্ত অ্যাপ নয়। Player profile editing, team logo upload UI, goal/card/substitution event editor, live match controls, penalty editor, automatic knockout advancement, statistics ও পূর্ণ bracket UI পরবর্তী development ধাপ।
- প্রথম seed/reset বাটনটি বিদ্যমান রেকর্ডে merge করে; তবুও প্রথমবার ডেটা তৈরির আগে সতর্ক থাকুন এবং পরে অকারণে চাপবেন না।
- Firebase project configuration এই প্রজেক্টের দেওয়া Android app ID/API key দিয়ে যুক্ত; API key গোপন পাসওয়ার্ড নয়, তবে Google Cloud Console-এ API restriction রাখা ভালো।
