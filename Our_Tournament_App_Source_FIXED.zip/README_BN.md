# Our Tournament — Android অ্যাপের সোর্স

এটি Flutter + Firebase দিয়ে তৈরি ১৬ দলের Knockout tournament app-এর প্রাথমিক সোর্স প্রজেক্ট।

## অ্যাপে যা আছে
- সবাই অ্যাপ খুলে ম্যাচ, স্কোর ও ফলাফল দেখতে পারবে।
- Admin হিসেবে `nasarulislam440@gmail.com` দিয়ে লগইন করলে Edit বাটন দেখা যাবে।
- ১৬ দলের Round of 16, ৪টি Quarter Final, ২টি Semi Final এবং ১টি Final — মোট ১৫টি ম্যাচ।
- দলের নাম, স্কোর, বিজয়ী এবং পরের রাউন্ডের দলের নাম Admin নিজে সম্পাদনা করতে পারবে।
- ডার্ক সবুজ ও সোনালি থিম।

## APK বানানোর জন্য যা লাগবে
এই ZIP-টি সরাসরি APK নয়; এটি Android app-এর source project। APK বানাতে কম্পিউটারে Flutter SDK ও Android Studio লাগবে।

1. Flutter ইনস্টল করে এই ফোল্ডার খুলুন।
2. Firebase Console-এ আপনার Firebase project খুলুন।
3. Android app যোগ করুন। Package name দিন: `com.ourtournament.app`
4. `google-services.json` ডাউনলোড করে `android/app/` ফোল্ডারে রাখুন।
5. টার্মিনালে চালান:
   - `flutter pub get`
   - `dart pub global activate flutterfire_cli`
   - `flutterfire configure`
   - `flutter build apk --release`
6. APK পাবেন: `build/app/outputs/flutter-apk/app-release.apk`

## Firebase সেটআপ
1. Firebase Authentication থেকে Email/Password sign-in চালু করুন।
2. Authentication > Users থেকে `nasarulislam440@gmail.com` অ্যাকাউন্ট তৈরি করুন। পাসওয়ার্ড অ্যাপের কোডে লেখা নেই।
3. Firestore Database > Rules-এ এই ZIP-এর `firestore.rules` ফাইলের নিয়ম বসিয়ে Publish করুন।
4. Admin অ্যাকাউন্ট ছাড়া অন্য কেউ Firestore-এ লিখতে পারবে না; সবাই পড়তে পারবে।

## প্রথমবার ব্যবহার
- Admin হিসেবে লগইন করুন।
- “১৫টি Knockout ম্যাচ তৈরি/রিসেট” বাটন চাপুন।
- প্রতিটি ম্যাচের Edit আইকন থেকে দল, স্কোর ও বিজয়ী দিন।
- Quarter Final, Semi Final ও Final-এর ম্যাচেও Edit করে যোগ্য দলগুলোর নাম বসান।

**সতর্কতা:** Reset বাটন আগে দেওয়া ম্যাচের তথ্য বদলে দিতে পারে। একবার ম্যাচের তথ্য দেওয়া শুরু করলে অকারণে Reset চাপবেন না।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই প্রজেক্টে আপনার Firebase-এর `google-services.json` এবং FlutterFire configuration নেই, তাই এখনই APK হিসেবে ইনস্টল করা যাবে না।
- বর্তমান সোর্সে পরের রাউন্ডের দল Admin হাতে বসাবে; বিজয়ী স্বয়ংক্রিয়ভাবে পরের ম্যাচে বসানোর ফিচার এখনো যোগ করা হয়নি।
- টুর্নামেন্টের approved logo image এই ZIP-এ অন্তর্ভুক্ত করা হয়নি; পরে image asset হিসেবে যোগ করতে হবে।
