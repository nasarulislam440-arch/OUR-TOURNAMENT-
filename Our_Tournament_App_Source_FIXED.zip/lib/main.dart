import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

const adminEmail = 'nasarulislam440@gmail.com';
const tournamentTitle =
    'আব্দুল হামিদ মেম্বার কর্তৃক আয়োজিত সৌদি রিয়াল প্রাইজমানি নাইট মিনিবার ফুটবল টুর্নামেন্ট';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Run: flutterfire configure
  runApp(const OurTournamentApp());
}

class OurTournamentApp extends StatelessWidget {
  const OurTournamentApp({super.key});

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFD8B45A);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Our Tournament',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07140F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF167A4A),
          brightness: Brightness.dark,
          primary: const Color(0xFF16834D),
          secondary: gold,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0B2117),
          foregroundColor: gold,
          centerTitle: true,
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF10271C),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: Color(0xFF345640)),
          ),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: const TournamentHome(),
    );
  }
}

class TournamentHome extends StatefulWidget {
  const TournamentHome({super.key});

  @override
  State<TournamentHome> createState() => _TournamentHomeState();
}

class _TournamentHomeState extends State<TournamentHome> {
  final db = FirebaseFirestore.instance;
  bool get isAdmin =>
      FirebaseAuth.instance.currentUser?.email?.toLowerCase() == adminEmail;

  final rounds = const [
    ('ROUND OF 16', 'প্রি-কোয়ার্টার ফাইনাল', 0, 8),
    ('QUARTER FINAL', 'কোয়ার্টার ফাইনাল', 8, 4),
    ('SEMI FINAL', 'সেমিফাইনাল', 12, 2),
    ('FINAL', 'ফাইনাল', 14, 1),
  ];

  Future<void> _initializeMatches() async {
    final batch = db.batch();
    for (int i = 1; i <= 15; i++) {
      final ref = db.collection('matches').doc('m$i');
      batch.set(ref, {
        'number': i,
        'round': i <= 8 ? 'Round of 16' : i <= 12 ? 'Quarter Final' : i <= 14 ? 'Semi Final' : 'Final',
        'teamA': 'দল ${i * 2 - 1}',
        'teamB': 'দল ${i * 2}',
        'scoreA': '',
        'scoreB': '',
        'winner': '',
      }, SetOptions(merge: true));
    }
    await batch.commit();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('১৫টি ম্যাচ তৈরি/আপডেট হয়েছে')),
      );
    }
  }

  Future<void> _editMatch(int number, Map<String, dynamic> data) async {
    final a = TextEditingController(text: '${data['teamA'] ?? ''}');
    final b = TextEditingController(text: '${data['teamB'] ?? ''}');
    final sa = TextEditingController(text: '${data['scoreA'] ?? ''}');
    final sb = TextEditingController(text: '${data['scoreB'] ?? ''}');
    String winner = '${data['winner'] ?? ''}';
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: Text('ম্যাচ $number এডিট'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: a, decoration: const InputDecoration(labelText: 'প্রথম দলের নাম')),
                const SizedBox(height: 10),
                TextField(controller: b, decoration: const InputDecoration(labelText: 'দ্বিতীয় দলের নাম')),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: TextField(controller: sa, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'স্কোর A'))),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: sb, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'স্কোর B'))),
                ]),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: winner,
                  decoration: const InputDecoration(labelText: 'বিজয়ী দল'),
                  items: [
                    const DropdownMenuItem(value: '', child: Text('এখনো নির্ধারিত নয়')),
                    DropdownMenuItem(value: a.text, child: Text(a.text.isEmpty ? 'দল A' : a.text)),
                    DropdownMenuItem(value: b.text, child: Text(b.text.isEmpty ? 'দল B' : b.text)),
                  ],
                  onChanged: (v) => setDialog(() => winner = v ?? ''),
                ),
                const SizedBox(height: 6),
                const Text('পরের রাউন্ডের ম্যাচে দল/নাম প্রয়োজন হলে সেই ম্যাচটিও এডিট করে দেবে।', style: TextStyle(fontSize: 12, color: Colors.white70)),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
            FilledButton(onPressed: () => Navigator.pop(ctx, {
              'teamA': a.text.trim(), 'teamB': b.text.trim(),
              'scoreA': sa.text.trim(), 'scoreB': sb.text.trim(),
              'winner': winner,
            }), child: const Text('সেভ')),
          ],
        ),
      ),
    );
    if (result != null) {
      // Keep winner valid if a team name was changed in the same edit.
      if (winner == '${data['teamA']}' && result['teamA'] != data['teamA']) result['winner'] = result['teamA']!;
      if (winner == '${data['teamB']}' && result['teamB'] != data['teamB']) result['winner'] = result['teamB']!;
      await db.collection('matches').doc('m$number').set(result, SetOptions(merge: true));
    }
  }

  Future<void> _adminLogin() async {
    final email = TextEditingController(text: adminEmail);
    final password = TextEditingController();
    final creds = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Admin Login'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: email, decoration: const InputDecoration(labelText: 'ইমেইল'), keyboardType: TextInputType.emailAddress),
          const SizedBox(height: 10),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'পাসওয়ার্ড')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(ctx, [email.text.trim(), password.text]), child: const Text('লগইন')),
        ],
      ),
    );
    if (creds == null) return;
    if (creds[0].toLowerCase() != adminEmail) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('এই ইমেইল Admin হিসেবে অনুমোদিত নয়')));
      return;
    }
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: creds[0], password: creds[1]);
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'লগইন হয়নি')));
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OUR TOURNAMENT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        actions: [
          IconButton(
            tooltip: isAdmin ? 'Admin logout' : 'Admin login',
            onPressed: () async {
              if (isAdmin) {
                await FirebaseAuth.instance.signOut();
                setState(() {});
              } else {
                await _adminLogin();
              }
            },
            icon: Icon(isAdmin ? Icons.logout : Icons.admin_panel_settings),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: db.collection('matches').orderBy('number').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('ডেটা লোড হয়নি: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          final byNumber = {for (final d in docs) (d.data()['number'] as int): d.data()};
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(children: [
                    const Icon(Icons.emoji_events, size: 48, color: Color(0xFFD8B45A)),
                    const SizedBox(height: 8),
                    const Text('Our Tournament', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFD8B45A))),
                    const SizedBox(height: 8),
                    Text(tournamentTitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.white70)),
                    const SizedBox(height: 6),
                    const Text('জালালাবাদ, ঈদগাঁও, কক্সবাজার', style: TextStyle(color: Colors.white70)),
                    if (isAdmin) const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Chip(avatar: Icon(Icons.verified_user, size: 16), label: Text('ADMIN MODE')),
                    ),
                  ]),
                ),
              ),
              if (isAdmin) ...[
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: _initializeMatches,
                  icon: const Icon(Icons.refresh),
                  label: const Text('১৫টি Knockout ম্যাচ তৈরি/রিসেট'),
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 5),
                  child: Text('প্রথমবার ডেটা তৈরি করতে এই বাটন চাপো। আগে থেকে দেওয়া ম্যাচের তথ্য রিসেট হতে পারে।', style: TextStyle(fontSize: 11, color: Colors.orangeAccent)),
                ),
              ],
              for (final round in rounds) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
                  child: Row(children: [
                    const Icon(Icons.sports_soccer, color: Color(0xFFD8B45A)),
                    const SizedBox(width: 8),
                    Text(round.$2, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFFD8B45A))),
                    const Spacer(),
                    Text('${round.$4} ম্যাচ', style: const TextStyle(color: Colors.white60, fontSize: 12)),
                  ]),
                ),
                for (int n = round.$3 + 1; n <= round.$3 + round.$4; n++)
                  _matchCard(n, byNumber[n] ?? {
                    'number': n, 'teamA': '—', 'teamB': '—',
                    'scoreA': '', 'scoreB': '', 'winner': ''
                  }),
              ],
              const SizedBox(height: 24),
              const Center(child: Text('Our Tournament • 16 Team Knockout', style: TextStyle(color: Colors.white38, fontSize: 11))),
            ],
          );
        },
      ),
    );
  }

  Widget _matchCard(int n, Map<String, dynamic> d) {
    final a = '${d['teamA'] ?? '—'}';
    final b = '${d['teamB'] ?? '—'}';
    final sa = '${d['scoreA'] ?? ''}';
    final sb = '${d['scoreB'] ?? ''}';
    final winner = '${d['winner'] ?? ''}';
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
        child: Column(children: [
          Row(children: [
            Text('MATCH $n', style: const TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.bold)),
            const Spacer(),
            if (winner.isNotEmpty) const Text('সম্পন্ন', style: TextStyle(color: Colors.greenAccent, fontSize: 11)),
            if (isAdmin) IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: () => _editMatch(n, d),
              icon: const Icon(Icons.edit, color: Color(0xFFD8B45A), size: 19),
            ),
          ]),
          Row(children: [
            Expanded(child: Text(a, style: TextStyle(fontWeight: FontWeight.w600, color: winner == a && winner.isNotEmpty ? Colors.greenAccent : Colors.white))),
            Text(sa.isEmpty ? '-' : sa, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Text(':', style: TextStyle(color: Colors.white54))),
            Text(sb.isEmpty ? '-' : sb, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            Expanded(child: Text(b, textAlign: TextAlign.end, style: TextStyle(fontWeight: FontWeight.w600, color: winner == b && winner.isNotEmpty ? Colors.greenAccent : Colors.white))),
          ]),
          if (winner.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('বিজয়ী: $winner', style: const TextStyle(color: Color(0xFFD8B45A), fontSize: 12)),
            ),
        ]),
      ),
    );
  }
}
